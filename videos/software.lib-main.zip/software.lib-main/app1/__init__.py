from .registro import registro
from .menu import menu
from .devolucion import vista_devolucion
from .prestamo import vista_prestamo